import { Component } from '@angular/core';

@Component({
  standalone: true,
  template: `<h2>Profile</h2><p>Account Holder</p>`
})
export class ProfileComponent {}
