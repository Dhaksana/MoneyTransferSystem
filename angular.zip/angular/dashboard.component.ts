import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../core/services/account.service';

@Component({
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {

  balance = 0;
  accountId = 1;

  constructor(private accountService: AccountService) {}

  ngOnInit() {
    this.accountService.getBalance(this.accountId)
      .subscribe(b => this.balance = b);
  }
}
