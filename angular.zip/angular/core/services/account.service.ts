import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private url = `${environment.apiUrl}/accounts`;

  constructor(private http: HttpClient) {}

  createAccount(body: any): Observable<any> {
    return this.http.post(this.url, body);
  }

  getBalance(id: number): Observable<number> {
    return this.http.get<number>(`${this.url}/${id}/balance`);
  }
}
