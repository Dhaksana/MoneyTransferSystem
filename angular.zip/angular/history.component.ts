import { Component, OnInit } from '@angular/core';
import { TransferService } from '../../core/services/transfer.service';

@Component({
  standalone: true,
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent implements OnInit {

  history: any[] = [];
  accountId = 1;

  constructor(private transferService: TransferService) {}

  ngOnInit() {
    this.transferService.history(this.accountId)
      .subscribe(data => this.history = data);
  }
}
