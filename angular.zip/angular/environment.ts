export const environment = {
  apiUrl: 'http://localhost:8080/api/v1'
};
