import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TransferService } from '../../core/services/transfer.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  templateUrl: './transfer.component.html',
  styleUrl: './transfer.component.css'
})
export class TransferComponent {

  fromAccountId = 1;
  toAccountId = 2;
  amount = 0;

  constructor(private transferService: TransferService) {}

  submit() {
    this.transferService.transfer({
      fromAccountId: this.fromAccountId,
      toAccountId: this.toAccountId,
      amount: this.amount,
      idempotencyKey: 'txn-' + Date.now()
    }).subscribe(res => alert(res.message));
  }
}
